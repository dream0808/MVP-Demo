// DSPTView.cpp : implementation of the CDSPTView class
//

#include "stdafx.h"
#include "DSPT.h"

#include "DSPTDoc.h"
#include "CntrItem.h"
#include "DSPTView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CRichEditCtrl* g_pEdit;

/////////////////////////////////////////////////////////////////////////////
// CDSPTView

IMPLEMENT_DYNCREATE(CDSPTView, CRichEditView)

BEGIN_MESSAGE_MAP(CDSPTView, CRichEditView)
	//{{AFX_MSG_MAP(CDSPTView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDSPTView construction/destruction

CDSPTView::CDSPTView()
{
	// TODO: add construction code here

}

CDSPTView::~CDSPTView()
{
}

BOOL CDSPTView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CRichEditView::PreCreateWindow(cs);
}

void CDSPTView::OnInitialUpdate()
{
	CRichEditView::OnInitialUpdate();

    g_pEdit = &(this->GetRichEditCtrl());
	// Set the printing margins (720 twips = 1/2 inch).
	SetMargins(CRect(720, 720, 720, 720));
}

void CDSPTView::OnDestroy()
{
	// Deactivate the item on destruction; this is important
	// when a splitter view is being used.
   CRichEditView::OnDestroy();
   COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
   if (pActiveItem != NULL && pActiveItem->GetActiveView() == this)
   {
      pActiveItem->Deactivate();
      ASSERT(GetDocument()->GetInPlaceActiveItem(this) == NULL);
   }
}


/////////////////////////////////////////////////////////////////////////////
// CDSPTView diagnostics

#ifdef _DEBUG
void CDSPTView::AssertValid() const
{
	CRichEditView::AssertValid();
}

void CDSPTView::Dump(CDumpContext& dc) const
{
	CRichEditView::Dump(dc);
}

CDSPTDoc* CDSPTView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDSPTDoc)));
	return (CDSPTDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDSPTView message handlers
