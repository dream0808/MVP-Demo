#if !defined(AFX_STACK_H_2C0fsDEFCDFXS7C48B39_4DGC_4E8__INCLUDED_)
#define AFX_STACK_H_2C0fsDEFCDFXS7C48B39_4DGC_4E8__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "dsptdef.h"
#define USE_BY_STUDENT


#define MAXSSIZE 100
typedef int SElemType;
typedef double DouElemType;

typedef struct 
{
    SElemType base[MAXSSIZE];
    SElemType *top;
    int stacksize;
}SqStack;

extern Status InitStack(SqStack &S);
extern Status Push(SqStack &S, SElemType e);
extern Status Pop(SqStack &S, SElemType &e);
extern SElemType GetTop(const SqStack &S);
extern Status IsStackEmpty(const SqStack &S); 
extern Status IsStackFull(const SqStack &S); 

#endif // !defined(AFX_STACK_H_2C0fsDEFCDFXS7C48B39_4DGC_4E8__INCLUDED_)