#if !defined(AFX_QUEUE_H_2C0fsCDFF7CB4839_4DGC_4E8__INCLUDED_)
#define AFX_QUEUE_H_2C0fsCDFF7CB4839_4DGC_4E8__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "dsptdef.h"
#define USE_BY_STUDENT

/*========================== ���� ================================*/
#define MAXQSIZE 10
typedef int QElemType;

typedef struct tagSqQueue
{
    QElemType *base;
    int  front; //����ָ��
    int  rear;  //��βָ��
} SqQueue; //ѭ���洢

extern Status InitQueue(SqQueue &Q);
extern Status EnQueue(SqQueue &Q, QElemType e);
extern Status DeQueue(SqQueue &Q, QElemType &e);
extern int QueueLength(const SqQueue &Q);
extern void QueueDestroy(SqQueue &Q);


#endif // !defined(AFX_CH_03_H_2C0Afs7CB_D13E_48394DGC4E8__INCLUDED_)
