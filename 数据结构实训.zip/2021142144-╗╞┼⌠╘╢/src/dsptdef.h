#ifndef __DS_PT_DEF_H_A33BEDG549KR_FH38Y4JIO0P4576JSDH__
#define __DS_PT_DEF_H_A33BEDG549KR_FH38Y4JIO0P4576JSDH__

#ifdef __cplusplus
extern "C" {
#endif

#define atFront 1
#define atEqual 0
#define atRear -1

#define OK       1
#define ERROR    0
#define OVERFLOW 2
typedef int Status;

extern Status EvaluateExpression(const char* s, int &reasult);

//���ֹ��������ݲ�ͬ�Ʒֹ�������ί����ѡ�ֵĳɼ�
extern void OnScoreManByRule1(const char* pszTextTblName);
extern void OnScoreManByRule2(const char* pszTextTblName);

#ifdef __cplusplus
}
#endif
#endif
