#include "stdafx.h"
#include "stack.h"

Status InitStack(SqStack &S)
{
/*	S.base=new SElemType[MAXSSIZE];
	if(!S.base) exit(OVERFLOW);
*/	
    S.top = S.base;
    S.stacksize = MAXSSIZE;
    return OK;
}

//��ջ
Status Push(SqStack &S, SElemType e)
{
    if(S.top-S.base==S.stacksize) return ERROR;
    *S.top++ = e;
    return OK;
}
//��ջ
Status Pop(SqStack &S, SElemType &e)
{
    if(S.top == S.base) return ERROR;
    e = *--S.top;
    return OK;
}
//ȡջ��Ԫ��
Status GetTop(const SqStack &S)
{
   if(S.base!=S.top)
    return *(S.top - 1);
   else 
	   return -1;
}
//ջ��
Status IsStackEmpty(const SqStack &S)
{
    return (S.top == S.base);
}

//ջ��
Status IsStackFull(const SqStack &S)
{
    return ((S.top - S.base) == S.stacksize);
}
