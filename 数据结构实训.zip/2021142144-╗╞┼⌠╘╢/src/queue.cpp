#include "stdafx.h"
#include "queue.h"


/*           ���ļ�ʵ�����ж��в����Ľӿ�              */

Status InitQueue(SqQueue &Q)
{
	Q.base=new QElemType[MAXQSIZE];
	if(!Q.base) exit(OVERFLOW);
	Q.front=Q.rear;
	return OK;
}
//����
Status EnQueue(SqQueue &Q, QElemType e)
{
	if((Q.rear+1)%MAXQSIZE==Q.front) return ERROR;//�ж�ջ��
	Q.base[Q.rear]=e;
	Q.rear=(Q.rear+1)%MAXQSIZE;
	return OK;
}
//����
Status DeQueue(SqQueue &Q, QElemType &e)
{
	if(Q.rear==Q.front)//�ж�ջ��
    return ERROR;
	e=Q.base[Q.front];
	Q.front=(Q.front+1)%MAXQSIZE;
	return OK;
}
//ȡ�ӳ�
int QueueLength(const SqQueue &Q)
{
  return (Q.rear-Q.front+MAXQSIZE)%MAXQSIZE;
}
//����ջ
void QueueDestroy(SqQueue &Q)
{
	/*if(Q.base)
		delete Q.base;
	Q.base=NULL;
	Q.front=NULL;
	*/
	
    if(Q.base) delete []Q.base;
	ZeroMemory(&Q,sizeof(Q));
  
  }


