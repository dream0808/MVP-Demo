// stdafx.cpp : source file that includes just the standard includes
//	DSPT.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"


CRichEditCtrl* g_pEdit = NULL;
static char gShowBuff[1024];

void ShowMsg(char *msg, ...)
{

    va_list ap;

    va_start(ap, msg);
    vsprintf(gShowBuff, msg, ap);
    va_end(ap);

    if (g_pEdit != NULL)
    {
        g_pEdit->SetSel(-1, -1);
        g_pEdit->ReplaceSel(gShowBuff);
        g_pEdit->SetModify(FALSE);
        TRACE(gShowBuff);
    }
}

CString GetDataPathName()
{
    char szPath[1024];
    CString strPath;
    int p;

    if (GetModuleFileName(NULL, szPath, sizeof(szPath)) < 1) return strPath;
    strPath = szPath;

    p = strPath.ReverseFind(_T('\\'));
    strPath = strPath.Left(p);
    p = strPath.ReverseFind(_T('\\'));
    strPath = strPath.Left(p);

    strPath +=  "\\Data";
    CreateDirectory(strPath, NULL);
    return strPath;
}

//��ȡANSI�����ʽ���ı��ļ�
bool ReadTextFile(LPCTSTR file, CStringArray &lines)
{
    CStdioFile f;
    CString s;

    if (!f.Open(file, CFile::modeRead)) return false;
    while (f.ReadString(s))
    {
        lines.Add(s);
    }
    f.Close();

    return true;
}

//д�ı��ļ�
bool WriteTextFile(LPCTSTR file, CStringArray &lines, bool bOverlay)
{
    CStdioFile f;
    CString s;
    UINT nFlag = bOverlay ? (CFile::modeCreate | CFile::modeWrite) : CFile::modeWrite;
    
    if (!f.Open(file, nFlag)) return false;
    for (int i = 0; i < lines.GetSize(); i++)
    {
        s = lines[i];
        s = s + _T("\n");
        f.WriteString(s);
    }
    f.Close();

    return true;
}
