// CntrItem.h : interface of the CDSPTCntrItem class
//

#if !defined(AFX_CNTRITEM_H__A2C5F840_0EE4_4D8F_91D4_190FE4C4F09E__INCLUDED_)
#define AFX_CNTRITEM_H__A2C5F840_0EE4_4D8F_91D4_190FE4C4F09E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDSPTDoc;
class CDSPTView;

class CDSPTCntrItem : public CRichEditCntrItem
{
	DECLARE_SERIAL(CDSPTCntrItem)

// Constructors
public:
	CDSPTCntrItem(REOBJECT* preo = NULL, CDSPTDoc* pContainer = NULL);
		// Note: pContainer is allowed to be NULL to enable IMPLEMENT_SERIALIZE.
		//  IMPLEMENT_SERIALIZE requires the class have a constructor with
		//  zero arguments.  Normally, OLE items are constructed with a
		//  non-NULL document pointer.

// Attributes
public:
	CDSPTDoc* GetDocument()
		{ return (CDSPTDoc*)CRichEditCntrItem::GetDocument(); }
	CDSPTView* GetActiveView()
		{ return (CDSPTView*)CRichEditCntrItem::GetActiveView(); }

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDSPTCntrItem)
	public:
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	~CDSPTCntrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CNTRITEM_H__A2C5F840_0EE4_4D8F_91D4_190FE4C4F09E__INCLUDED_)
