// DSPTView.h : interface of the CDSPTView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DSPTVIEW_H__CF94A6EA_E81D_41E0_8CFE_FDDEC9371F0C__INCLUDED_)
#define AFX_DSPTVIEW_H__CF94A6EA_E81D_41E0_8CFE_FDDEC9371F0C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDSPTCntrItem;

class CDSPTView : public CRichEditView
{
protected: // create from serialization only
	CDSPTView();
	DECLARE_DYNCREATE(CDSPTView)

// Attributes
public:
	CDSPTDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDSPTView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDSPTView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDSPTView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in DSPTView.cpp
inline CDSPTDoc* CDSPTView::GetDocument()
   { return (CDSPTDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DSPTVIEW_H__CF94A6EA_E81D_41E0_8CFE_FDDEC9371F0C__INCLUDED_)
