// DlgQueue.cpp : implementation file
//

#include "stdafx.h"
#include "DSPT.h"
#include "DlgQueue.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BOOL IsUsedByStudent()
{
    #ifdef USE_BY_STUDENT
    return TRUE;
    #endif
    return FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// CDlgQueue dialog
CDlgQueue::CDlgQueue(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgQueue::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgQueue)
	m_nWinNum = 5;
	m_nWinNo = 1;
	//}}AFX_DATA_INIT
    m_Seq = 0;
}


void CDlgQueue::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgQueue)
	DDX_Control(pDX, CMD_SET_WIN_NUM, m_cmdSetWinNum);
	DDX_Control(pDX, IDC_EDT_WIN_NUM, m_txtWinNum);
	DDX_Text(pDX, IDC_EDT_WIN_NUM, m_nWinNum);
	DDV_MinMaxInt(pDX, m_nWinNum, 1, 10);
	DDX_Text(pDX, IDC_EDT_WIN_NO, m_nWinNo);
	DDV_MinMaxInt(pDX, m_nWinNo, 1, 10);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDlgQueue, CDialog)
	//{{AFX_MSG_MAP(CDlgQueue)
	ON_BN_CLICKED(CMD_SET_WIN_NUM, OnSetWinNum)
	ON_BN_CLICKED(CMD_CUSTOMER_ARRIVE, OnCustomerArrive)
	ON_BN_CLICKED(CMD_QUEUE_LEAVE, OnQueueLeave)
	ON_BN_CLICKED(CMD_VIEW_QUEUE, OnViewQueue)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgQueue message handlers

void CDlgQueue::OnSetWinNum() 
{
    this->UpdateData(TRUE);
    InitQueues();
}

void CDlgQueue::InitQueues()
{
    for (int i = 1; i <= m_nWinNum; i++)
    {
        SqQueue &Q = m_Queue[i];
        if (!Q.base) InitQueue(Q);
    }

    m_txtWinNum.EnableWindow(FALSE);
    m_cmdSetWinNum.EnableWindow(FALSE);
}

BOOL CDlgQueue::OnInitDialog() 
{
    CString strWin;

	CDialog::OnInitDialog();
	
    strWin.Format("ģ���Ŷ�ϵͳ[MAXQSIZE = %d]", MAXQSIZE);
    this->SetWindowText(strWin);
    
    ZeroMemory(m_Queue, sizeof(m_Queue));
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CDlgQueue::DestroyWindow() 
{
    for (int i = 1; i <= m_nWinNum; i++)
    {
        SqQueue &Q = m_Queue[i];
        if (Q.base) QueueDestroy(Q);
    }

    return CDialog::DestroyWindow();
}

void CDlgQueue::OnCustomerArrive() 
{
    int nQueueLen, idx = -1, n;

    InitQueues();

    //������̶���
    nQueueLen = MAXQSIZE;
    for (int i = 1; i <= m_nWinNum; i++)
    {
        SqQueue &Q = m_Queue[i];
        n = QueueLength(Q);
        if (n < nQueueLen)
        {
            nQueueLen = n;
            idx = i;
        }
    }

    if (idx < 0)
    {
        SHOW_MSG("������δ��ʼ����ȫ����");
        return;
    }

    SqQueue &Q = m_Queue[idx];
    QElemType e = ++m_Seq;
    if (EnQueue(Q, e) == OK)
    {
        SHOW_MSG("�µ��˿� %d �� %d# �����Ŷӡ�\r\n", e, idx);
    }
    else
    {
        SHOW_MSG("���д�����������\r\n");
    }
}

void CDlgQueue::OnQueueLeave() 
{
	this->UpdateData(TRUE);

    InitQueues();

    SqQueue &Q = m_Queue[m_nWinNo];
    QElemType e;

    if (DeQueue(Q, e) == OK)
    {
        SHOW_MSG("�˿� %d �� %d �������.\r\n", e, m_nWinNo);
    }
    else
    {
        SHOW_MSG("%d �����޹˿��Ŷ�.\r\n", m_nWinNo);
    }
}

void CDlgQueue::OnViewQueue() 
{
    InitQueues();

    for (int i = 1; i <= m_nWinNum; i++)
    {
        SqQueue &Q = m_Queue[i];
        int n = QueueLength(Q);

        SHOW_MSG("���� %d �Ŷ����� %d��front = %d, rear = %d��\r\n", i, n, Q.front, Q.rear);
    }

    SHOW_MSG("\r\n");
}

