// CntrItem.cpp : implementation of the CDSPTCntrItem class
//

#include "stdafx.h"
#include "DSPT.h"

#include "DSPTDoc.h"
#include "DSPTView.h"
#include "CntrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDSPTCntrItem implementation

IMPLEMENT_SERIAL(CDSPTCntrItem, CRichEditCntrItem, 0)

CDSPTCntrItem::CDSPTCntrItem(REOBJECT* preo, CDSPTDoc* pContainer)
	: CRichEditCntrItem(preo, pContainer)
{
	// TODO: add one-time construction code here
	
}

CDSPTCntrItem::~CDSPTCntrItem()
{
	// TODO: add cleanup code here
	
}

/////////////////////////////////////////////////////////////////////////////
// CDSPTCntrItem diagnostics

#ifdef _DEBUG
void CDSPTCntrItem::AssertValid() const
{
	CRichEditCntrItem::AssertValid();
}

void CDSPTCntrItem::Dump(CDumpContext& dc) const
{
	CRichEditCntrItem::Dump(dc);
}
#endif

/////////////////////////////////////////////////////////////////////////////
