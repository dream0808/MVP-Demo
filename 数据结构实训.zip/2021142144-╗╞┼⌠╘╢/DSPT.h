// DSPT.h : main header file for the DSPT application
//

#if !defined(AFX_DSPT_H__FE828387_12FE_4935_80A3_0E8615DB0CCB__INCLUDED_)
#define AFX_DSPT_H__FE828387_12FE_4935_80A3_0E8615DB0CCB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDSPTApp:
// See DSPT.cpp for the implementation of this class
//

class CDSPTApp : public CWinApp
{
public:
	CDSPTApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDSPTApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CDSPTApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DSPT_H__FE828387_12FE_4935_80A3_0E8615DB0CCB__INCLUDED_)
