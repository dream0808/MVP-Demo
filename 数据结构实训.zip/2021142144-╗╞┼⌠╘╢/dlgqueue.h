#if !defined(AFX_DLGQUEUE_H__61DFBC1C_96C0_49CC_BE44_4B8BB6E8EF5A__INCLUDED_)
#define AFX_DLGQUEUE_H__61DFBC1C_96C0_49CC_BE44_4B8BB6E8EF5A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgQueue.h : header file
//

#include "queue.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgQueue dialog

class CDlgQueue : public CDialog
{
// Construction
public:
	CDlgQueue(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgQueue)
	enum { IDD = IDD_DLG_QUEUE };
	CButton	m_cmdSetWinNum;
	CEdit	m_txtWinNum;
	int		m_nWinNum;
	int		m_nWinNo;
	//}}AFX_DATA

private:
    int     m_Seq;
    SqQueue m_Queue[11];

    void InitQueues();


    // Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgQueue)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgQueue)
	afx_msg void OnSetWinNum();
	virtual BOOL OnInitDialog();
	afx_msg void OnCustomerArrive();
	afx_msg void OnQueueLeave();
	afx_msg void OnViewQueue();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGQUEUE_H__61DFBC1C_96C0_49CC_BE44_4B8BB6E8EF5A__INCLUDED_)
