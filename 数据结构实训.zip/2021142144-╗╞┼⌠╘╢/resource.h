//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DSPT.rc
//
#define CMD_SET_WIN_NUM                 3
#define CMD_CALC                        3
#define CMD_CALC_SHORTEST_PATH          3
#define CMD_CUSTOMER_ARRIVE             4
#define CMD_VIEW_QUEUE                  5
#define IDR_CNTR_INPLACE                6
#define CMD_QUEUE_LEAVE                 6
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDP_FAILED_TO_CREATE            102
#define IDR_MAINFRAME                   128
#define IDR_DSPTTYPE                    129
#define IDD_DLG_QUEUE                   130
#define IDD_DLG_CALC_EXP                131
#define IDD_DLG_SHORT_PATH              132
#define IDC_EDT_WIN_NUM                 1000
#define IDC_EDT_WIN_NO                  1001
#define IDC_EDT_EXP                     1003
#define IDC_EDT_FILE                    1004
#define IDC_BUTTON1                     1005
#define IDC_BUTTON2                     1006
#define IDC_BUTTON3                     1007
#define IDC_BUTTON4                     1008
#define IDC_BUTTON5                     1009
#define IDC_BUTTON6                     1010
#define IDC_BUTTON7                     1011
#define IDC_BUTTON8                     1012
#define IDC_BUTTON9                     1013
#define IDC_BUTTON10                    1014
#define IDC_BUTTON11                    1015
#define IDC_BUTTON12                    1016
#define IDC_BUTTON13                    1017
#define IDC_BUTTON14                    1018
#define IDC_BUTTON15                    1019
#define IDC_BUTTON16                    1020
#define IDC_BUTTON_CALC                 1021
#define IDC_BUTTON_DEL                  1022
#define IDC_BUTTON_CLR                  1023
#define IDC_EDIT1                       1024
#define ID_CANCEL_EDIT_CNTR             32768
#define ID_MNU_QUEUE                    32771
#define ID_MNU_CAL_EXP                  32772
#define ID_SHORTEST_PATH                32773
#define ID_SCORE_MAN_RULE2              32775
#define ID_SCORE_MAN_RULE1              32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
