// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "DSPT.h"
#include "MainFrm.h"
#include "DlgQueue.h"
#include "DlgExpCalc.h"
#include "textdb.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern bool ReadTextFile(LPCTSTR file, CStringArray &lines);

static CStringArray g_arrRemark;

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_MNU_QUEUE, OnMnuQueue)
	ON_COMMAND(ID_MNU_CAL_EXP, OnMnuCalExp)
	ON_COMMAND(ID_SCORE_MAN_RULE1, OnScoreManRule1)
	ON_COMMAND(ID_SCORE_MAN_RULE2, OnScoreManRule2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	cs.style = WS_OVERLAPPED | WS_CAPTION | FWS_ADDTOTITLE
		| WS_THICKFRAME | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_MAXIMIZE;

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::OnMnuQueue() 
{
    CDlgQueue dlg;

    dlg.DoModal();
}

void CMainFrame::OnMnuCalExp() 
{
	CDlgExpCalc dlg;
    dlg.DoModal();
}

void CMainFrame::OnScoreManRule1() 
{
    char szFile[MAX_PATH];

    sprintf(szFile, "%s\\score.txt", GetDataPathName());

    SHOW_MSG("���ݹ���1�Ʒֽ����\r\n");
    OnScoreManByRule1(szFile);
}

void CMainFrame::OnScoreManRule2() 
{
    char szFile[MAX_PATH];

    sprintf(szFile, "%s\\score.txt", GetDataPathName());

    SHOW_MSG("���ݹ���2�Ʒֽ����\r\n");
    OnScoreManByRule2(szFile);
}

void ShowRemark(LPCTSTR lpszName)
{
    CString strFile, strBegin, strEnd, s;
    CStringArray lines;
    BOOL bStart= FALSE;
    int i;

    for (i = 0; i < g_arrRemark.GetSize(); i++)
    {
        if (g_arrRemark[i] == lpszName) return; /* �Ѿ���ʾ����������ʾ */
    }
    g_arrRemark.Add(lpszName);

    strFile = GetDataPathName() + _T("\\require.txt");

    if (!ReadTextFile(strFile, lines)) return;

    strBegin.Format("<%s>", lpszName);
    strEnd.Format("</%s>", lpszName);
    for (i = 0; i < lines.GetSize(); i++)
    {
        s = lines[i];
        if (bStart)
        {
            if (s == strEnd) break;
            SHOW_MSG("%s\r\n", s);
        }
        else if (s == strBegin)
        {
            bStart = TRUE;
        }
    }
}
