// DlgExpCalc.cpp : implementation file
//

#include "stdafx.h"
#include "DSPT.h"
#include "DlgExpCalc.h"
#include "dsptdef.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static CString g_strExp;

/////////////////////////////////////////////////////////////////////////////
// CDlgExpCalc dialog


CDlgExpCalc::CDlgExpCalc(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgExpCalc::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgExpCalc)
	//}}AFX_DATA_INIT
}


void CDlgExpCalc::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgExpCalc)
	DDX_Control(pDX, IDC_EDT_EXP, m_txtExp);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDlgExpCalc, CDialog)
	//{{AFX_MSG_MAP(CDlgExpCalc)
	ON_BN_CLICKED(CMD_CALC, OnCalc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgExpCalc message handlers

void CDlgExpCalc::OnCalc() 
{
    CString strExp, strExpCall;

    m_txtExp.GetWindowText(strExp);
    if (strExp == "") return;

    strExpCall = strExp + _T("#");
    const char *s = (const char*)strExpCall;
    int result;

    if (EvaluateExpression(s, result) == OK)
    {
        SHOW_MSG("%s = %d\r\n", strExp, result);
        g_strExp = strExp;
    }
    else
    {
        SHOW_MSG("%s �޷�����.\r\n", strExp);
    }
}

BOOL CDlgExpCalc::OnCommand(WPARAM wParam, LPARAM lParam) 
{
    WORD wNotifyCode = HIWORD(wParam); // notification code 
    WORD wID = LOWORD(wParam);         // item, control, or accelerator identifier

    if (wNotifyCode == 0)
    {
        CString strText;

        switch (wID)
        {
        case IDC_BUTTON_DEL:
            m_txtExp.GetWindowText(strText);
            if (!strText.IsEmpty())
            {
                strText = strText.Left(strText.GetLength() - 1);
                m_txtExp.SetWindowText(strText);
                m_txtExp.SetSel(strText.GetLength(), strText.GetLength());
            }
            break;

        case IDC_BUTTON_CLR:
            m_txtExp.SetWindowText("");
            break;

        case IDC_BUTTON_CALC:
            OnCalc();
            break;

        default:
	        GetDlgItemText(wID, strText);
            m_txtExp.SetSel(-1, -1);
            m_txtExp.ReplaceSel(strText);
        }
    }

	return CDialog::OnCommand(wParam, lParam);
}

BOOL CDlgExpCalc::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
    m_txtExp.EnableWindow(FALSE);

    if (g_strExp == "") g_strExp = _T("1+2*3+15/(5-2)");
    m_txtExp.SetWindowText(g_strExp);
    m_txtExp.SetSel(g_strExp.GetLength(), g_strExp.GetLength());
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
